﻿app.controller("DashBoardController", function ($scope, $http) {
    $scope.model = {};
    $scope.details = {};
    $scope.isClosed = false;
    $scope.model.FromDate = moment().subtract(30, "days").format("DD-MM-YYYY");
    $scope.model.ToDate = moment().add(1, 'days').format("DD-MM-YYYY");
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }
    $scope.BranchDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Branch",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Group/GetBranch"
                }
            }
        },
        dataBound: function (e) {
           

        },

        filter: "contains",
        suggest: true
    };



    $scope.SubjectDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Subject",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "DashBoard/GetSubject"
                }
            }
        },
        dataBound: function (e) {


        },

        filter: "contains",
        suggest: true
    };


    $scope.StatusDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Status",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "DashBoard/GetStatus"
                }
            }
        },
        
        filter: "contains",
        suggest: true
    };

    $scope.GroupDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Group",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Compose/GetGroup"
                }
            }
        },
        filter: "contains",
        suggest: true
    };

    $scope.checkData = function (e) {
        $("#messageGrid").data("kendoGrid").dataSource.read();
    }
    $scope.OnGroupComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("GroupId", null);

        }       
         //  $scope.GetDashBoardDetails();
        $("#messageGrid").data("kendoGrid").dataSource.read();
       
    }

    $scope.OnSubjectComboBoxChange= function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("SubjectId", null);

        }
        $("#messageGrid").data("kendoGrid").dataSource.read();
    }

    $scope.OnStatusComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("StatusId", null);

        }
       
           // $scope.GetDashBoardDetails();
            $("#messageGrid").data("kendoGrid").dataSource.read();
      

    }

    $scope.OnBranchComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("BranchId", null);

        }
       
            //$scope.GetDashBoardDetails();
             $("#messageGrid").data("kendoGrid").dataSource.read();
       

    }


    $scope.GetHeaderDetails = function () {
        
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: baseUrl + 'DashBoard/GetDashBoardHeader'
          
        }).then(function (response) {
            $scope.ShowLoaderImg();
            var result = [];
            if (response.data) {
                for (var i = 0; i < response.data.length; i++) {
                    result.push({ Name: response.data[i].name, Total: response.data[i].Total });
                }

            }
            $scope.list = result;
           // $scope.GetDashBoardDetails();
            $scope.HideLoaderImg();

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
        });
    }
   

    $scope.messageGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "DashBoard/GetDashBoardMessages",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                   
                    //opt.BranchId = $("#BranchId").data('kendoComboBox').value();
                    //opt.GroupId = $("#GroupId").data('kendoComboBox').value();
                    opt.Subject = getComboText("SubjectId");
                    opt.StatusId = getComobBoxValue("StatusId");
                    opt.FromDate = $scope.model.FromDate;
                    opt.ToDate = $scope.model.ToDate;
                  
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {
                               // createddate: { type: "date"}
                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
       
        columns: [
               {
                   field: "Subject",
                   title: "Subject",
                   width: "80px",
                   filterable: false,

               },
                 {
                     field: "Message",
                     title: "Message",
                     width: "150px",
                     filterable: false,

                 },
                 {
                     field: "EmployeeName",
                     title: "Employee",
                     width: "80px",
                     filterable: false,

                 },
                 {
                     field: "Branch",
                     title: "Branch",
                     width: "80px",
                     filterable: false,

                 },
                 {
                     field: "Status",
                     title: "Status",
                     width: "80px",
                     filterable: false,

                 },
                  {
                      field: "Reply",
                      title: "Reply",
                      width: "80px",
                      filterable: false,
                      hidden: true,

                  },
                 {
                     field: "CreatedBy",
                     title: "Created By",
                     width: "80px",
                     filterable: false,

                 },

                 {
                   field: "CreatedDate", title: "Created Date", width: "80px",
                   type: "date",
                    format: "{0:dd-MMM-yyyy hh:mm tt}"
                                     
                 },
        
               {

                

                   template: "#  if (Status == 'Completed' ) { # <a href='javascript:void(0);' ng-click='changeStatus(this)'  data-toggle='tooltip' title='Close' <i class='las la-times-circle text-danger'></i> </a> \ <a href='javascript:void(0);' class='btn-edit'  ng-click='showPopup(this)'  data-toggle='tooltip'  title='View'><i class='las la-info-circle'></i></a>#} \
                  else if (Status == 'Pending' ) { # <a href='javascript:void(0);' class='btn-edit'  ng-click='showPopup(this)'  data-toggle='tooltip'  title='View'><i class='las la-info-circle'></i></a> \ <a href='javascript:void(0);' ng-click='forceClose(this)'  data-toggle='tooltip' title='Force Close' <i class='las la-times-circle text-danger'></i> </a> #} \
                   else { # <a href='javascript:void(0);' class='btn-edit'  ng-click='showPopup(this)'  data-toggle='tooltip'  title='View'><i class='las la-info-circle'></i></a> #} \#",
                   width: "40px",
                   title: "Action",
                  headerAttributes: { style: "text-align:center;" },
                  attributes: { style: "text-align:center;" },


               }

        ]
    };


    $scope.GetDashBoardDetails = function () {

        $scope.details = {};
        $scope.details.BranchId = getComobBoxValue("BranchId");
        $scope.details.GroupId = getComobBoxValue("GroupId");
        $scope.details.StatusId = getComobBoxValue("StatusId");
        $scope.details.FromDate = $scope.model.FromDate;
        $scope.details.ToDate = $scope.model.ToDate;
        $scope.ShowLoaderImg();


        $http({
            method: 'POST',
            url: baseUrl + 'DashBoard/GetDashBoardDetails',
            data: $scope.details,
        }).then(function (response) {
            debugger;
           
            var result = [];
            $scope.details = [];
            if (response.data) {
                for (var i = 0; i < response.data.length; i++) {
                    result.push({ Id: response.data[i].Id, Subject: response.data[i].Subject, Message: response.data[i].Message, EmployeeName: response.data[i].EmployeeName, Branch: response.data[i].Branch, Status: response.data[i].Status, Reply: response.data[i].Reply, CreatedDate: response.data[i].CreatedDate, CreatedBy: response.data[i].CreatedBy });
                }

            }
            $scope.details = result;
            $scope.HideLoaderImg();

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
           

        });


       
    }

    $scope.GetAllReplies=function(e)
    {
        debugger;
        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: baseUrl + 'DashBoard/GetAllReplies?Id=' + $scope.model.MessageDetailId,

        }).then(function (response) {
            debugger;
            var result = [];
         
           
            if (response.data.length>0) {
                   result.push({ MessageDetailId: $scope.model.MessageDetailId, Message: e.Message, Reply: e.Reply, CreatedBy: e.CreatedBy, EmployeeName: e.EmployeeName });
                for (var i = 0; i < response.data.length; i++) {                 
                    result.push({ MessageDetailId: $scope.model.MessageDetailId,  Message: response.data[i].Message,  Reply: response.data[i].Reply,CreatedBy: e.CreatedBy, EmployeeName:e.EmployeeName});
                    if (response.data.length -i == 1)
                    {
                        if (response.data[i].Reply == '' || response.data[i].Reply == null || response.data[i].Reply==undefined)
                        {
                            $scope.model.ShowButton = false;
                        }
                        else

                        {
                            $scope.model.ShowButton = true;
                        }
                    }
                }

            }
            else
            {
                if (e.Reply == '' || e.Reply == null || e.Reply == undefined) {
                    $scope.model.ShowButton = false;
                }
                else {
                    $scope.model.ShowButton = true;
                }

                result.push({ MessageDetailId: $scope.model.MessageDetailId, Message: e.Message, Reply: e.Reply, CreatedBy: e.CreatedBy, EmployeeName: e.EmployeeName });
               
            }
            $scope.details = result;
            $scope.model.SendMessage = "";
            if (e.Status == "Closed")
                $scope.isClosed = true;
            
            $scope.winOptions = {
                title: "View",
                // activate: $scope.activate
            }
            $scope.WinDashBoard.setOptions($scope.winOptions);
            $scope.WinDashBoard.open().center();
            $scope.HideLoaderImg();

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });
    }
   

    $scope.showPopup = function (e) {
        debugger       
        if (e.dataItem != null) {


            var dataItem = e.dataItem;
            if (dataItem) {
                $scope.model.MessageDetailId = dataItem.Id;
                $scope.model.Message = dataItem.Message;
                $scope.model.Reply = dataItem.Reply;
                $scope.model.CreatedBy = dataItem.CreatedBy;
                $scope.model.EmployeeName = dataItem.EmployeeName;
                $scope.GetAllReplies(dataItem);
               
               
            }
            else {
                $scope.clearFields();
            }
        }
       


      

    };

    $scope.closeSubject = function () {
        if ($scope.model.SubjectId == '' || $scope.model.SubjectId == null || $scope.model.SubjectId == undefined)
            SetMessage('Select');
        else {
            var selected = $scope.model.SubjectId;
            var warnText = "Are you sure you want to close all completed chats of selected subject?";
            $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
                if (confirmed) {
                    $scope.ShowLoaderImg();
                    $http({
                        method: 'GET',
                        url: baseUrl + 'DashBoard/CloseSelectedSubject?Id=' + selected,

                    }).then(function (response) {
                        debugger;
                        $scope.HideLoaderImg()
                        SetMessage('Update');
                        $scope.GetHeaderDetails();
                        $("#messageGrid").data("kendoGrid").dataSource.read();

                    }, function errorCallback(response) {
                        $scope.HideLoaderImg();
                        SetMessage('Error');

                    });
                }
            });
        }

    }

    $scope.forceCloseSubject = function () {
        if ($scope.model.SubjectId == '' || $scope.model.SubjectId == null || $scope.model.SubjectId == undefined)
            SetMessage('Select');
        else {
            var selected = $scope.model.SubjectId;
            var warnText = "Are you sure you want to close all chats of selected subject forcefully?";
            $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
                if (confirmed) {
                    $scope.ShowLoaderImg();
                    $http({
                        method: 'GET',
                        url: baseUrl + 'DashBoard/CloseSelectedSubjectForcefully?Id=' + selected,

                    }).then(function (response) {
                        debugger;
                        $scope.HideLoaderImg()
                        SetMessage('Update');
                        $scope.GetHeaderDetails();
                        $("#messageGrid").data("kendoGrid").dataSource.read();

                    }, function errorCallback(response) {
                        $scope.HideLoaderImg();
                        SetMessage('Error');

                    });
                }
            });
        }

    }


    $scope.closeAll=function()
    {
        var warnText = "Are you sure you want to close all completed records?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'DashBoard/CloseAll',

                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');
                    $scope.GetHeaderDetails();
                    $("#messageGrid").data("kendoGrid").dataSource.read();

                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });

    }

    $scope.changeStatus=function(obj)
    {              
        var warnText = "Are you sure you want to close this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'DashBoard/ChangeStatusToClose?Id=' + obj.dataItem.Id,
                   
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');
                    $scope.GetHeaderDetails();
                    $("#messageGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });


    }


    $scope.forceClose = function (obj) {
        var warnText = "Are you sure you want to close this record forcefully?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'DashBoard/ChangeStatusToCloseForcefully?Id=' + obj.dataItem.Id,

                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');
                    $scope.GetHeaderDetails();
                    $("#messageGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });


    }

    $scope.Cancel=function(e)
    {
        $scope.WinDashBoard.close();

    }

    $scope.Reply = function (e) {
        if ($scope.ReplyValidator.validate()) {
            $scope.ShowLoaderImg();
            $scope.Message = {};
            $scope.Message.MessageDetailId = $scope.model.MessageDetailId;
            $scope.Message.SendMessage = $scope.model.SendMessage;
            $http({
                method: 'POST',
                url: baseUrl + 'DashBoard/SubmitReply',
                data: $scope.Message,
            }).then(function (response) {
                debugger;
               


                //$scope.model.MessageDetailId = dataItem.Id;
                //$scope.model.Message = dataItem.Message;
                //$scope.model.Reply = dataItem.Reply;
                //$scope.model.CreatedBy = dataItem.CreatedBy;
                //$scope.model.EmployeeName = dataItem.EmployeeName;


                $scope.HideLoaderImg();
                 $scope.WinDashBoard.close();
              //  $scope.GetAllReplies($scope.model);
              //  SetMessage('Save')
                $("#messageGrid").data("kendoGrid").dataSource.read();


            }, function errorCallback(response) {
               
                $scope.HideLoaderImg();
                SetMessage('Error');

            });

        }
    }

});